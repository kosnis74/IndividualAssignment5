﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace EmployeeList
{
    [Activity(Label = "Add New Employee")]
    public class AddEmployeeActivity : Activity
    {
        EditText txtSKFirstName;
        EditText txtSKLastName;
        EditText txtSKJobTitle;
        Button btnSKAddEmployee;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here

            SetContentView(Resource.Layout.AddEmployee);

            txtSKFirstName = FindViewById<EditText>(Resource.Id.txtSKFirstName);
            txtSKLastName = FindViewById<EditText>(Resource.Id.txtSKLastName);
            txtSKJobTitle = FindViewById<EditText>(Resource.Id.txtSKJobTitle);

            btnSKAddEmployee = FindViewById<Button>(Resource.Id.btnSKAddEmployee);
            btnSKAddEmployee.Click += BtnAddEmployee_Click;

        }

        void BtnAddEmployee_Click(object sender, EventArgs e)
        {

        }
    }
}