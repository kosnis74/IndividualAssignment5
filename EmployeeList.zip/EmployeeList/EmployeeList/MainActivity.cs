﻿using Android.App;
using Android.Widget;
using Android.OS;
using System;

namespace EmployeeList
{
    [Activity(Label = "Home Screen", MainLauncher = true)]
    public class MainActivity : Activity
    {
        EditText txtSKUsername;
        EditText txtSKPassword;
        Button btnSKAdminLogin;
        Button btnSKListGoTo;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            btnSKAdminLogin = FindViewById<Button>(Resource.Id.btnSKAdminLogin);
            btnSKAdminLogin.Click += BtnAdminLogin_Click;

            btnSKListGoTo = FindViewById<Button>(Resource.Id.btnSKListGoTo);
            btnSKListGoTo.Click += BtnGoToList_Click;

            txtSKPassword = FindViewById<EditText>(Resource.Id.txtSKPassword);
            txtSKUsername = FindViewById<EditText>(Resource.Id.txtSKUsername);

        }

        void BtnAdminLogin_Click(object sender, EventArgs e)
        {
            

        }

        void BtnGoToList_Click(object sender, EventArgs e)
        {
            var intent = new intent(this, typeof(EmployeeListActivity));
            StartActivity(intent);
        }


    }
}

